export class User {
    EmpID: number;
    FirstName: string;
    LastName: string;
    Gender: string;
    Email: string;
}
